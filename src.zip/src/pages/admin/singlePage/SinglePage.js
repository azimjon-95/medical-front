import React, { useEffect } from "react";
import "./style.css";
import axios from "../../../api";
import GetPatients from "./getPatients/GetPatients";
import SingleReports from "./singleReports/SingleReports";
import { useGetAllUsersQuery } from "../../../redux/apiSlice";

const SinglePage = () => {
  // ----------------------------------------

  let { data: allClients } = useGetAllUsersQuery();
  let clients = allClients?.data;
  console.log(clients);

  return (
    <div className="SearchBar-Box">
      <GetPatients />

      <SingleReports />
    </div>
  );
};

export default SinglePage;
